import java.util.Scanner;
import java.util.concurrent.Semaphore;

public class OficinaSemaforos {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int puestos = 0, empleados = 0;
        while (puestos <= 0) {
            System.out.print("Número de puestos/ordenadores: ");
            if (sc.hasNextInt()) puestos = sc.nextInt(); else sc.next();
        }

        while (empleados <= puestos) {
            System.out.print("Número de empleados (> puestos): ");
            if (sc.hasNextInt()) empleados = sc.nextInt(); else sc.next();
        }
        sc.nextLine(); // limpiar buffer

        Semaphore semPuestos = new Semaphore(puestos, true);
        Semaphore semOrdenadores = new Semaphore(puestos, true);

        Thread[] hilos = new Thread[empleados];
        for (int i = 0; i < empleados; i++) {
            Thread t = new Thread(new Empleado(i + 1, semPuestos, semOrdenadores), "Empleado-" + (i + 1));
            hilos[i] = t;
            t.start();
        }

        for (Thread t : hilos) {
            try {
                t.join();
            } catch (InterruptedException e) {
                System.out.println("Main interrumpido.");
                Thread.currentThread().interrupt();
            }
        }

        System.out.println("Simulación finalizada. Todos los empleados terminaron sus ciclos.");
        sc.close();
    }
}
