import java.util.Random;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;

public class Empleado implements Runnable {

    private final int id;
    private final Semaphore puestos;
    private final Semaphore ordenadores;
    private final Random rnd = new Random();

    // Constantes de trabajo y descanso
    private static final int NUM_CICLOS = 5;
    private static final int MIN_WORK_MS = 500;
    private static final int MAX_WORK_MS = 1500;
    private static final int MIN_BREAK_MS = 300;
    private static final int MAX_BREAK_MS = 1000;
    private static final int ACQUIRE_TIMEOUT_MS = 300;

    public Empleado(int id, Semaphore puestos, Semaphore ordenadores) {
        this.id = id;
        this.puestos = puestos;
        this.ordenadores = ordenadores;
    }

    @Override
    public void run() {
        for (int ciclo = 1; ciclo <= NUM_CICLOS; ciclo++) {
            boolean pedirPuestoPrimero = rnd.nextBoolean();
            log("llega y quiere trabajar (ciclo " + ciclo + "/" + NUM_CICLOS + "). Orden: "
                    + (pedirPuestoPrimero ? "Puesto→PC" : "PC→Puesto"));

            boolean adquiridos = false;
            while (!adquiridos) {
                try {
                    if (pedirPuestoPrimero) {
                        if (puestos.tryAcquire(ACQUIRE_TIMEOUT_MS, TimeUnit.MILLISECONDS)) {
                            log("ha reservado un PUESTO (temporal). Intentando coger ORDENADOR...");
                            if (ordenadores.tryAcquire(ACQUIRE_TIMEOUT_MS, TimeUnit.MILLISECONDS)) {
                                adquiridos = true;
                                log("ha conseguido ORDENADOR también. ¡Empieza a trabajar!");
                            } else {
                                puestos.release();
                                log("no pudo conseguir ORDENADOR, libera PUESTO y espera antes de reintentar.");
                                dormirAleatorioPequeño();
                            }
                        } else {
                            log("no hay PUESTO disponible ahora. Reintentando...");
                            dormirAleatorioPequeño();
                        }
                    } else {
                        if (ordenadores.tryAcquire(ACQUIRE_TIMEOUT_MS, TimeUnit.MILLISECONDS)) {
                            log("ha reservado un ORDENADOR (temporal). Intentando coger PUESTO...");
                            if (puestos.tryAcquire(ACQUIRE_TIMEOUT_MS, TimeUnit.MILLISECONDS)) {
                                adquiridos = true;
                                log("ha conseguido PUESTO también. ¡Empieza a trabajar!");
                            } else {
                                ordenadores.release();
                                log("no pudo conseguir PUESTO, libera ORDENADOR y espera antes de reintentar.");
                                dormirAleatorioPequeño();
                            }
                        } else {
                            log("no hay ORDENADOR disponible ahora. Reintentando...");
                            dormirAleatorioPequeño();
                        }
                    }
                } catch (InterruptedException e) {
                    log("interrumpido mientras intentaba adquirir recursos.");
                    Thread.currentThread().interrupt();
                    return;
                }
            }

            int tiempoTrabajo = aleatorioEntre(MIN_WORK_MS, MAX_WORK_MS);
            log("trabajando durante " + tiempoTrabajo + " ms.");
            try {
                Thread.sleep(tiempoTrabajo);
            } catch (InterruptedException e) {
                log("interrumpido mientras trabajaba.");
                Thread.currentThread().interrupt();
            }

            puestos.release();
            ordenadores.release();
            log("ha liberado PUESTO y ORDENADOR y se va a descansar.");

            int tiempoDescanso = aleatorioEntre(MIN_BREAK_MS, MAX_BREAK_MS);
            try {
                Thread.sleep(tiempoDescanso);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }

        log("ha terminado todos sus ciclos y se marcha.");
    }

    private void log(String msg) {
        System.out.printf("[%s] Empleado-%d: %s%n", Thread.currentThread().getName(), id, msg);
    }

    private void dormirAleatorioPequeño() {
        try {
            Thread.sleep(50 + rnd.nextInt(150));
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    private int aleatorioEntre(int min, int max) {
        return min + rnd.nextInt(max - min + 1);
    }
}
