import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

/**
 * Programa principal:
 * - Pide el número de clientes.
 * - Crea la CuentaBancaria (con SALDO_INICIAL_CENTS).
 * - Crea y lanza N clientes (hilos).
 * - Espera a que terminen y verifica que el saldo final coincide con:
 *     SALDO_INICIAL + totalDepositado - totalRetirado
 *
 * Notas:
 * - Todas las cantidades manejadas en céntimos (long) para evitar doubles.
 */
public class BancoApp {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        DecimalFormat df = new DecimalFormat("#,##0.00");

        System.out.println("=== Simulación Banco (acceso concurrente) ===");
        int nClients = 0;
        while (nClients <= 0) {
            System.out.print("Número de clientes (enteros positivos): ");
            try {
                nClients = sc.nextInt();
                if (nClients <= 0) {
                    System.out.println("Introduce un número positivo mayor que 0.");
                }
            } catch (InputMismatchException ex) {
                System.out.println("Entrada inválida. Introduce un entero.");
                sc.next(); // limpiar
            }
        }

        // Crear cuenta con saldo inicial constante
        CuentaBancaria cuenta = new CuentaBancaria();
        System.out.println("Saldo inicial de la cuenta: " + df.format(CuentaBancaria.SALDO_INICIAL_CENTS / 100.0) + " EUR");

        // Crear clientes (hilos)
        List<Cliente> clientes = new ArrayList<>();
        for (int i = 1; i <= nClients; i++) {
            Cliente c = new Cliente("Cliente-" + i, cuenta);
            clientes.add(c);
        }

        // Iniciar clientes
        System.out.println("Arrancando " + nClients + " clientes...");
        for (Cliente c : clientes) {
            c.start();
        }

        // Esperar a terminación de todos los clientes
        for (Cliente c : clientes) {
            try {
                c.join();
            } catch (InterruptedException e) {
                System.out.println("Main interrumpido mientras espera a clientes.");
                Thread.currentThread().interrupt();
            }
        }

        // Al finalizar comprobamos la consistencia
        long saldoFinal = cuenta.getSaldoCents();
        long depositado = cuenta.getTotalDepositadoCents();
        long retirado = cuenta.getTotalRetiradoCents();
        long saldoEsperado = CuentaBancaria.SALDO_INICIAL_CENTS + depositado - retirado;

        System.out.println("\n=== RESUMEN FINAL ===");
        System.out.println("Saldo inicial  : " + df.format(CuentaBancaria.SALDO_INICIAL_CENTS / 100.0) + " EUR");
        System.out.println("Total deposit. : " + df.format(depositado / 100.0) + " EUR");
        System.out.println("Total retirado : " + df.format(retirado / 100.0) + " EUR");
        System.out.println("Saldo esperado : " + df.format(saldoEsperado / 100.0) + " EUR");
        System.out.println("Saldo real     : " + df.format(saldoFinal / 100.0) + " EUR");

        if (saldoFinal == saldoEsperado) {
            System.out.println("VERIFICACIÓN: OK — la cuenta es consistente.");
        } else {
            System.out.println("VERIFICACIÓN: ERROR — hay inconsistencia en las operaciones.");
        }

        sc.close();
    }
}
