import java.text.DecimalFormat;

/**
 * CuentaBancaria: clase que representa una cuenta bancaria compartida entre hilos.
 * - El saldo y totales se guardan en 'cents' (long) para evitar problemas con decimales.
 * - Se usan métodos sincronizados para evitar condiciones de carrera.
 *
 * Constante pública SALDO_INICIAL_CENTS para fijar el saldo inicial según enunciado.
 */
public class CuentaBancaria {

    // SALDO INICIAL (en céntimos) => 1000.00 EUR = 100000 céntimos
    public static final long SALDO_INICIAL_CENTS = 1000_00L;

    // Formateador para mostrar euros
    private static final DecimalFormat DF = new DecimalFormat("#,##0.00");

    // Estado interno: todos en céntimos (long)
    private long saldoCents;
    private long totalDepositadoCents;
    private long totalRetiradoCents;

    // Constructor inicializa saldo a la constante
    public CuentaBancaria() {
        this.saldoCents = SALDO_INICIAL_CENTS;
        this.totalDepositadoCents = 0L;
        this.totalRetiradoCents = 0L;
    }

    /**
     * Devuelve el saldo actual (en céntimos) de forma sincronizada.
     */
    public synchronized long getSaldoCents() {
        return saldoCents;
    }

    /**
     * Deposita una cantidad en céntimos. Método sincronizado para proteger la operación.
     * Actualiza saldo y totalDepositadoCents.
     */
    public synchronized void depositar(long amountCents) {
        if (amountCents <= 0) return;
        saldoCents += amountCents;
        totalDepositadoCents += amountCents;
    }

    /**
     * Intenta retirar amountCents. Si no hay saldo suficiente devuelve false y no modifica nada.
     * Operación sincronizada para evitar race conditions.
     */
    public synchronized boolean retirar(long amountCents) {
        if (amountCents <= 0) return false;
        if (amountCents > saldoCents) {
            // No permitir números rojos
            return false;
        }
        saldoCents -= amountCents;
        totalRetiradoCents += amountCents;
        return true;
    }

    /** Devuelve total depositado (céntimos) */
    public synchronized long getTotalDepositadoCents() {
        return totalDepositadoCents;
    }

    /** Devuelve total retirado (céntimos) */
    public synchronized long getTotalRetiradoCents() {
        return totalRetiradoCents;
    }

    /** Muestra saldo en formato euros (string). */
    public synchronized String mostrarSaldoFormateado() {
        return DF.format(saldoCents / 100.0);
    }

    /** Método auxiliar para debug: mostrar resumen de totales en euros. */
    public synchronized String resumenOperacion() {
        return "Saldo=" + mostrarSaldoFormateado()
                + " | Depositado=" + DF.format(totalDepositadoCents / 100.0)
                + " | Retirado=" + DF.format(totalRetiradoCents / 100.0);
    }
}
