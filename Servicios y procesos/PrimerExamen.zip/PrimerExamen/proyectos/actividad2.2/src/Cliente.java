import java.util.Random;

/**
 * Cliente: representa un cliente que realiza operaciones sobre una CuentaBancaria.
 * - Extiende Thread según pide el enunciado (la clase Cliente es el Thread).
 * - Realiza un número aleatorio de operaciones (hasta MAX_OPERATIONS), cada una de tipo
 *   depósito o retirada, con pausas aleatorias entre operaciones.
 *
 * Constantes que se pueden ajustar:
 *   MAX_OPERATIONS: máximo de operaciones por cliente
 *   MAX_AMOUNT_CENTS: cantidad máxima por operación (en céntimos)
 *   MAX_PAUSE_MS: tiempo máximo de espera entre operaciones (ms)
 */
public class Cliente extends Thread {

    // Constantes (puedes cambiarlas si quieres probar)
    public static final int MAX_OPERATIONS = 20;
    public static final int MAX_AMOUNT_CENTS = 50_000; // 500.00 EUR
    public static final int MAX_PAUSE_MS = 1000; // 1 segundo

    private final CuentaBancaria cuenta;
    private final Random rnd;

    public Cliente(String nombre, CuentaBancaria cuenta) {
        super(nombre); // nombre del hilo = nombre del cliente
        this.cuenta = cuenta;
        this.rnd = new Random();
    }

    @Override
    public void run() {
        // Número aleatorio de operaciones entre 1 y MAX_OPERATIONS
        int operaciones = rnd.nextInt(MAX_OPERATIONS) + 1;

        for (int i = 1; i <= operaciones; i++) {
            // Decidir si es depósito o retirada (50/50)
            boolean esDeposito = rnd.nextBoolean();

            // Generar cantidad aleatoria entre 1 y MAX_AMOUNT_CENTS
            long cantidad = (long) (rnd.nextInt(MAX_AMOUNT_CENTS) + 1);

            if (esDeposito) {
                // Depositar
                cuenta.depositar(cantidad);
                System.out.printf("%s | OPERACIÓN: DEPOSITAR | Cantidad: %.2f EUR | %s%n",
                        getName(), cantidad / 100.0, cuenta.resumenOperacion());
            } else {
                // Intentar retirar
                boolean ok = cuenta.retirar(cantidad);
                if (ok) {
                    System.out.printf("%s | OPERACIÓN: RETIRAR | Cantidad: %.2f EUR | %s%n",
                            getName(), cantidad / 100.0, cuenta.resumenOperacion());
                } else {
                    System.out.printf("%s | OPERACIÓN: RETIRAR FALLIDA (Saldo insuficiente) | Intentada: %.2f EUR | %s%n",
                            getName(), cantidad / 100.0, cuenta.resumenOperacion());
                }
            }

            // Pausa aleatoria antes de la siguiente operación
            try {
                int pausa = rnd.nextInt(MAX_PAUSE_MS + 1); // 0..MAX_PAUSE_MS ms
                Thread.sleep(pausa);
            } catch (InterruptedException e) {
                // Si se interrumpe, dejamos que el hilo termine limpiamente
                System.out.println(getName() + " interrumpido.");
                Thread.currentThread().interrupt();
                break;
            }
        }

        System.out.println(getName() + " ha terminado sus operaciones.");
    }
}
