import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class menu {
    public static void main(String[] args) {
        boolean win = false;
        String nombreSO = System.getProperty("os.name");
        if (nombreSO.toLowerCase().contains("win")) {
            win = true;
        }
        Scanner sc = new Scanner(System.in);

        int opcion;
        do {
            System.out.println("Elige una opcion del menu:");
            System.out.println("1.Ejecutar un ping");
            System.out.println("2.listar archivos y ficheros");
            System.out.println("3. Cerrar un procesos del sistema");
            System.out.println("4.Ejecutar un navegador");
            System.out.println("5.Salir");

            opcion = sc.nextInt();
            sc.nextLine();
            switch (opcion) {
                case 1:
                    ProcessBuilder pb;
                    System.out.println("introduce el destino del ping:");
                    String destino= sc.nextLine();
                    if(win){
                        pb = new ProcessBuilder("ping", "-n", "4", destino);
                    }else {
                        pb = new ProcessBuilder("ping", "-c", "4", destino);
                    }
                    pb.redirectErrorStream(true);

                    try {
                        Process proceso = pb.start();

                        BufferedReader reader = new BufferedReader(new InputStreamReader(proceso.getInputStream()));
                        String linea;
                        while ((linea = reader.readLine()) != null) {
                            System.out.println(linea);
                        }
                        int exitCode = proceso.waitFor();
                        System.out.println("Proceso finalizado con código: " + exitCode);



                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    } catch (InterruptedException e) {
                        throw new RuntimeException(e);
                    }


                    break;
                case 2:
                    System.out.print("Introduce el nombre del archivo o ruta donde guardar la lista: ");
                    String nombreArchivo = sc.nextLine().trim();

                    if (nombreArchivo.isEmpty()) {
                        System.out.println("Nombre de archivo vacío. Cancela la operación.");
                        break;
                    }

                    ProcessBuilder pb2;
                    if (win) {
                        // En Windows, el comando es: cmd /c dir > nombreArchivo
                        pb2 = new ProcessBuilder("cmd", "/c", "dir > " + nombreArchivo);
                    } else {
                        // En Linux o Mac, el comando es: sh -c ls > nombreArchivo
                        pb2 = new ProcessBuilder("sh", "-c", "ls > " + nombreArchivo);
                    }

                    pb2.redirectErrorStream(true); // unir errores con salida normal

                    Process proceso = null;
                    try {
                        proceso = pb2.start();
                        int exitCode = proceso.waitFor();

                        if (exitCode == 0) {
                            System.out.println("Lista de archivos guardada en: " + nombreArchivo);
                        } else {
                            System.out.println("Error al ejecutar el comando.");
                        }
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    } catch (InterruptedException e) {
                        throw new RuntimeException(e);
                    }


                    break;


                case 3:
                    System.out.println("Listando procesos del sistema...");

                    ProcessBuilder pbList;
                    if (win) {
                        // Windows: listar procesos
                        pbList = new ProcessBuilder("tasklist");
                    } else {
                        // Linux/Mac: listar procesos con PID y nombre
                        pbList = new ProcessBuilder("ps", "-e", "-o", "pid,uid,comm");
                    }

                    pbList.redirectErrorStream(true);

                    try {
                        // Ejecutar proceso de listado
                        Process pList = pbList.start();

                        // Leer salida línea por línea
                        BufferedReader readerList = new BufferedReader(new InputStreamReader(pList.getInputStream()));
                        String lineaList;
                        while ((lineaList = readerList.readLine()) != null) {
                            System.out.println(lineaList);
                        }

                        int codeList = pList.waitFor();
                        System.out.println("Listado terminado con código: " + codeList);
                        readerList.close();

                        // Pedir PID al usuario
                        System.out.print("PID a terminar (vacío para cancelar): ");
                        String pid = sc.nextLine().trim();
                        if (pid.isEmpty()) {
                            System.out.println("Operación cancelada.");
                            break;
                        }

                        // Preparar comando para matar proceso
                        ProcessBuilder pbKill;
                        if (win) {
                            pbKill = new ProcessBuilder("taskkill", "/PID", pid, "/F");
                        } else {
                            pbKill = new ProcessBuilder("kill", "-9", pid);
                        }
                        pbKill.redirectErrorStream(true);

                        // Ejecutar kill
                        Process pKill = pbKill.start();
                        BufferedReader readerKill = new BufferedReader(new InputStreamReader(pKill.getInputStream()));
                        String lineaKill;
                        while ((lineaKill = readerKill.readLine()) != null) {
                            System.out.println(lineaKill);
                        }

                        int codeKill = pKill.waitFor();
                        System.out.println("Proceso terminado con código: " + codeKill);
                        readerKill.close();

                    } catch (IOException e) {
                        System.out.println("Error de E/S: " + e.getMessage());
                    } catch (InterruptedException e) {
                        System.out.println("Proceso interrumpido.");
                        Thread.currentThread().interrupt();
                    }

                    break;

                case 4:
                    System.out.print("Introduce la URL a abrir en el navegador: ");
                    String url = sc.nextLine().trim();

                    if (url.isEmpty()) {
                        System.out.println("Operación cancelada.");
                        break;
                    }

                    ProcessBuilder pbNavegador;
                    if (win) {
                        // Windows: cmd /c start "" <url>
                        pbNavegador = new ProcessBuilder("cmd", "/c", "start", "", url);
                    } else {
                        // Linux/Mac: xdg-open <url>
                        pbNavegador = new ProcessBuilder("xdg-open", url);
                    }

                    pbNavegador.redirectErrorStream(true);

                    try {
                        Process pNavegador = pbNavegador.start();
                        System.out.println("Comando lanzado. El navegador debería abrir la URL.");
                        pNavegador.waitFor(); // opcional, esperar a que el comando termine
                    } catch (IOException e) {
                        System.out.println("Error al ejecutar el comando: " + e.getMessage());
                    } catch (InterruptedException e) {
                        System.out.println("Proceso interrumpido.");
                        Thread.currentThread().interrupt();
                    }

                    break;

            }

        } while (opcion != 5);
        System.out.println("fin del programa");

    }
}
