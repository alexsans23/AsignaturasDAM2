import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class BuscadorTexto {

    public static void main(String[] args) {
        if (args.length < 2) {
            System.err.println("Uso: java BuscadorTexto <PALABRA> <FICHERO>");
            System.exit(2);
        }

        String palabra = args[0];
        String fichero = args[1];
        long contador = 0;
        String palabraUpper = palabra.toUpperCase();

        try (BufferedReader br = new BufferedReader(new FileReader(fichero))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                if (linea.toUpperCase().equals(palabraUpper)) {
                    contador++;
                }
            }
        } catch (IOException e) {
            System.err.println("Error al leer " + fichero + ": " + e.getMessage());
            System.exit(3);
        }

        System.out.println("RESULT:" + fichero + ":" + palabra + ":" + contador);
        System.exit(0);
    }
}
