import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class GestorBusqueda {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Introduce el texto a buscar (CASA, PERRO o COCHE): ");
        String palabra = sc.nextLine().trim();

        if (palabra.isEmpty()) {
            System.out.println("Palabra vacía. Saliendo.");
            sc.close();
            return;
        }

        // Ruta al ejecutable java y classpath actual
        String javaBin = System.getProperty("java.home") + System.getProperty("file.separator") +
                "bin" + System.getProperty("file.separator") + "java";
        String classpath = System.getProperty("java.class.path");

        System.out.println("DEBUG: java bin = " + javaBin);
        System.out.println("DEBUG: classpath = " + classpath);

        List<String> ficheros = new ArrayList<>();
        for (int i = 1; i <= 5; i++) {
            ficheros.add("texto" + i + ".txt");
        }

        List<Process> procesos = new ArrayList<>();

        try {
            // Lanzar un proceso hijo por cada fichero
            for (String fichero : ficheros) {
                ProcessBuilder pb = new ProcessBuilder(
                        javaBin,
                        "-cp",
                        classpath,
                        "BuscadorTexto", // sin paquete
                        palabra,
                        fichero
                );
                pb.redirectErrorStream(true);
                Process p = pb.start();
                procesos.add(p);
                System.out.println("Lanzado búsqueda en " + fichero);
            }

            // Leer resultados de cada proceso hijo
            for (Process p : procesos) {
                try (BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
                    String line;
                    while ((line = br.readLine()) != null) {
                        if (line.startsWith("RESULT:")) {
                            String[] parts = line.split(":", 4);
                            if (parts.length == 4) {
                                String ficheroName = parts[1];
                                String palabraR = parts[2];
                                String contador = parts[3];
                                System.out.println("RESULTADO -> Fichero: " + ficheroName +
                                        " | Palabra: " + palabraR + " | Apariciones: " + contador);
                            } else {
                                System.out.println("[HIJO] " + line);
                            }
                        } else {
                            System.out.println("[HIJO] " + line);
                        }
                    }
                }
                int exit = p.waitFor();
                System.out.println("Proceso hijo finalizó con código: " + exit);
            }

        } catch (Exception e) {
            System.out.println("Error en la ejecución: " + e.getMessage());
            e.printStackTrace();
        } finally {
            sc.close();
        }

        System.out.println("Búsqueda finalizada.");
    }
}
