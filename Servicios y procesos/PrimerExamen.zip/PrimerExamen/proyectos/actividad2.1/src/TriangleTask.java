import java.text.DecimalFormat;

public class TriangleTask implements Runnable {
    private final double base;
    private final double height;
    private final int index;
    private final int priority; // 1..10, or -1 if not set

    public TriangleTask(int index, double base, double height, int priority) {
        this.index = index;
        this.base = base;
        this.height = height;
        this.priority = priority;
    }

    /**
     * Método que calcula el producto base * height cumpliendo la restricción:
     * - Evitamos usar '*' para el producto de parte entera x entero (hacemos sumas repetidas).
     * - Para la parte fraccionaria usamos multiplicación (permitida para la parte decimal).
     *
     * Esto devuelve base * height.
     */
    private double multiplyUsingSumsWhenPossible(double a, double b) {
        // Separamos la parte entera de b y la fraccionaria
        long bInt = (long) Math.floor(Math.abs(b)); // parte entera no negativa
        double bFrac = Math.abs(b) - bInt; // parte fraccionaria

        double result = 0.0;

        // Sumamos 'a' bInt veces (esto evita usar multiplicación para la parte entera)
        // Si bInt es 0 no entra en el bucle.
        for (long i = 0; i < bInt; i++) {
            result += a; // suma repetida
        }

        // Para la parte fraccionaria multiplicamos (permitido para la parte decimal)
        if (bFrac > 0.0) {
            result += a * bFrac;
        }

        // Si b era negativo, ajustamos signo
        if (b < 0) result = -result;

        return result;
    }

    /**
     * Calcula el área del triángulo respetando la limitación:
     * area = (base * height) / 2
     * pero base*height se calcula con sumas para la parte entera de height y con multiplicación
     * solo para la parte fraccionaria (tal y como pide el enunciado).
     */
    private double computeArea() {
        // Calculamos el producto base * height usando la función anterior
        double product = multiplyUsingSumsWhenPossible(base, height);
        // Dividimos entre 2 (operación permitida)
        return product / 2.0;
    }

    /** Imprime de forma atómica (para que no se mezclen impresiones de distintos hilos). */
    private void printResult(double area) {
        // Precio estético: formateamos a 6 decimales para una salida limpia
        DecimalFormat df = new DecimalFormat("#.######");
        StringBuilder sb = new StringBuilder();
        sb.append("HILO-").append(index);
        sb.append(" | Thread name=").append(Thread.currentThread().getName());
        sb.append(" | Priority=").append(Thread.currentThread().getPriority());
        sb.append(" | Base=").append(df.format(base));
        sb.append(" | Height=").append(df.format(height));
        sb.append(" | Area=").append(df.format(area));
        // imprimimos en una llamada (atomicidad relativa)
        System.out.println(sb.toString());
    }

    @Override
    public void run() {
        // Mensaje inicial indicando que el hilo empieza (opcional)
        System.out.println("HILO-" + index + " (" + Thread.currentThread().getName() + ") iniciando cálculo...");
        // Calcular área
        double area = computeArea();
        // Mostrar resultado
        printResult(area);
        // Mensaje final (opcional)
        System.out.println("HILO-" + index + " finalizado.");
    }
}
