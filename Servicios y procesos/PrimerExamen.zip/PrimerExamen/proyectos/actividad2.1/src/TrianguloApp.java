import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

public class TrianguloApp {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("=== Cálculo de áreas de triángulos (por hilos) ===");

        int n = 0;
        while (n <= 0) {
            System.out.print("¿Cuántos triángulos quieres calcular? ");
            try {
                n = sc.nextInt();
                if (n <= 0) {
                    System.out.println("Introduce un número entero positivo mayor que 0.");
                }
            } catch (InputMismatchException ex) {
                System.out.println("Entrada no válida. Introduce un número entero.");
                sc.next(); // limpiar token inválido
            }
        }

        // ¿Desea el usuario asignar prioridades?
        boolean usePriorities = false;
        sc.nextLine(); // consumir resto de línea
        while (true) {
            System.out.print("¿Quieres asignar prioridad al cálculo de los triángulos? (S/N) ");
            String respuesta = sc.nextLine().trim();
            if (respuesta.equalsIgnoreCase("S")) {
                usePriorities = true;
                break;
            } else if (respuesta.equalsIgnoreCase("N")) {
                usePriorities = false;
                break;
            } else {
                System.out.println("Respuesta no válida. Escribe S o N.");
            }
        }

        // Guardamos los datos introducidos por el usuario
        List<Double> bases = new ArrayList<>(n);
        List<Double> heights = new ArrayList<>(n);
        List<Integer> priorities = new ArrayList<>(n); // -1 si no se asigna

        for (int i = 1; i <= n; i++) {
            double base = 0.0;
            double height = 0.0;
            int prio = -1;

            // Leer base (decimal permitido)
            while (true) {
                System.out.print("Triángulo " + i + " - introduce la base (decimal permitido): ");
                try {
                    base = Double.parseDouble(sc.nextLine().trim());
                    break;
                } catch (NumberFormatException ex) {
                    System.out.println("Valor no válido. Introduce un número (por ejemplo 3.5).");
                }
            }

            // Leer altura (decimal permitido)
            while (true) {
                System.out.print("Triángulo " + i + " - introduce la altura (decimal permitido): ");
                try {
                    height = Double.parseDouble(sc.nextLine().trim());
                    break;
                } catch (NumberFormatException ex) {
                    System.out.println("Valor no válido. Introduce un número (por ejemplo 2.75).");
                }
            }

            // Si el usuario quiere prioridades, preguntamos la prioridad (entero 1..10)
            if (usePriorities) {
                while (true) {
                    System.out.print("Triángulo " + i + " - introduce la prioridad (1-10): ");
                    try {
                        prio = Integer.parseInt(sc.nextLine().trim());
                        if (prio < 1 || prio > 10) {
                            System.out.println("La prioridad debe ser un entero entre 1 y 10.");
                        } else {
                            break;
                        }
                    } catch (NumberFormatException ex) {
                        System.out.println("Valor no válido. Introduce un entero (por ejemplo 5).");
                    }
                }
            } else {
                prio = -1; // no asignada
            }

            bases.add(base);
            heights.add(height);
            priorities.add(prio);
        } // fin recolección datos

        // Crear hilos (uno por triángulo) y prepararlos
        List<Thread> threads = new ArrayList<>(n);
        for (int i = 0; i < n; i++) {
            TriangleTask task = new TriangleTask(i + 1, bases.get(i), heights.get(i), priorities.get(i));
            Thread t = new Thread(task, "Triangulo-Hilo-" + (i + 1));
            // Si se especificó prioridad, asignarla (Thread.setPriority acepta 1..10)
            if (priorities.get(i) != -1) {
                try {
                    t.setPriority(priorities.get(i));
                } catch (IllegalArgumentException ex) {
                    // Si el valor no es válido (por seguridad), dejamos la prioridad por defecto
                }
            }
            threads.add(t);
        }

        System.out.println("\nTodos los hilos creados. Iniciando ejecución simultánea...");

        // Iniciar todos los hilos "a la vez" (en la práctica: en rápida sucesión)
        for (Thread t : threads) {
            t.start();
        }

        // Esperar a que todos los hilos terminen (join)
        for (Thread t : threads) {
            try {
                t.join();
            } catch (InterruptedException e) {
                System.out.println("Main interrumpido mientras esperaba hilos.");
                Thread.currentThread().interrupt();
            }
        }

        System.out.println("Todos los cálculos han terminado. Saliendo del programa.");
        sc.close();
    }
}
