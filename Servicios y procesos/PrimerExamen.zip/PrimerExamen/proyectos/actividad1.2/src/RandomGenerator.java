// RandomGenerator.java
public class RandomGenerator {
    public static void main(String[] args) {
        // Generamos un número aleatorio natural sencillo: un dígito 0-9
        int n = (int) (Math.random() * 10); // 0..9
        // Imprimimos el número y añadimos un salto de línea para que el padre pueda leer con readLine()
        System.out.print(n);
        // Salimos (código 0 por defecto)
    }
}
