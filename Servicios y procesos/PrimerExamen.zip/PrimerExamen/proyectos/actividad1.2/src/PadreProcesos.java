import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Scanner;

public class PadreProcesos {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce líneas (escribe 'fin' para terminar).");

        // Carpeta de clases compiladas relativa al proyecto
        String classpath = System.getProperty("user.dir") + "\\out\\production\\actividad1.2";

        while (true) {
            System.out.print("> ");
            String linea = sc.nextLine().trim();

            if (linea.equalsIgnoreCase("fin")) {
                System.out.println("Finalizando.");
                break;
            }

            // Por cada carácter de la línea, lanzamos un proceso hijo RandomGenerator
            for (int i = 0; i < linea.length(); i++) {
                try {
                    ProcessBuilder pb = new ProcessBuilder(
                            "java",
                            "-cp",
                            classpath,
                            "RandomGenerator"
                    );

                    pb.redirectErrorStream(true); // unir errores y salida normal
                    Process proceso = pb.start();

                    // Leer la salida del proceso hijo
                    BufferedReader reader = new BufferedReader(
                            new InputStreamReader(proceso.getInputStream())
                    );
                    String salida;
                    while ((salida = reader.readLine()) != null) {
                        System.out.println(salida);
                    }

                    int exitCode = proceso.waitFor(); // esperar a que termine el hijo
                    reader.close();

                } catch (Exception e) {
                    System.out.println("Error al ejecutar RandomGenerator: " + e.getMessage());
                }
            }
        }

        sc.close();
    }
}
